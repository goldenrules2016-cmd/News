import anthropic

def handler(request):
    """Vercel serverless function — proxies all AI calls securely."""
    import json, os
    from http.server import BaseHTTPRequestHandler

    # ── CORS headers for browser access ──────────────────────────────────────
    headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
        "Content-Type": "application/json",
    }

    # Handle preflight
    if request.method == "OPTIONS":
        return Response("", 200, headers)

    try:
        body = json.loads(request.body)
        action = body.get("action", "")
        topic  = body.get("topic", "").strip()

        client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])

        # ── SEARCH ────────────────────────────────────────────────────────────
        if action == "search":
            msg = client.messages.create(
                model="claude-opus-4-5",
                max_tokens=800,
                system="""You help YouTubers find copyright-free images for news videos.
Given a news topic return ONLY valid JSON with no extra text:
{"queries":["q1","q2","q3","q4","q5"],"metaphors":["idea1","idea2","idea3"],
"bestSource":"Source Name","bestSourceReason":"one sentence"}
bestSource must be exactly one of: VOA (Voice of America), Al Jazeera CC Repository,
DVIDS (Defense Visual), NASA Image Library, Wikimedia Commons, PIB India (Govt Photos),
European Commission Photos, UK Parliament Flickr, Kremlin.ru (Russia),
National Archives Australia, Pexels, Unsplash""",
                messages=[{"role":"user","content":f"News topic: {topic}"}]
            )
            return Response(clean_json(msg.content[0].text), 200, headers)

        # ── TRENDING ──────────────────────────────────────────────────────────
        elif action == "trending":
            msg = client.messages.create(
                model="claude-opus-4-5",
                max_tokens=1200,
                system="""You are a news editor. Generate 8 major current global news topics
a YouTube news creator would cover. Return ONLY a valid JSON array with no extra text:
[{"headline":"Short punchy headline","category":"Politics","urgency":"breaking",
"imageQuery":"copyright-free search query","region":"Global"}]
category: Politics, War, Tech, Economy, Climate, Science, India, World
urgency: breaking, trending, developing""",
                messages=[{"role":"user","content":"Top 8 news stories for YouTube news creators right now"}]
            )
            return Response(clean_json(msg.content[0].text), 200, headers)

        # ── COPYRIGHT CHECK ───────────────────────────────────────────────────
        elif action == "check":
            msg = client.messages.create(
                model="claude-opus-4-5",
                max_tokens=500,
                system="""You are a copyright expert for YouTube creators. Return ONLY valid JSON:
{"verdict":"SAFE","color":"#4CAF50","title":"Short title",
"explanation":"2-3 sentences","recommendation":"What to do instead"}
verdict: SAFE=public domain/CC0/US Govt, RISKY=CC BY/OGL/conditions,
DANGER=Reuters/AP/AFP/Getty/ANI/PTI/paid agency, UNKNOWN=cannot determine""",
                messages=[{"role":"user","content":f"Image source to check: {topic}"}]
            )
            return Response(clean_json(msg.content[0].text), 200, headers)

        # ── SCRIPT ────────────────────────────────────────────────────────────
        elif action == "script":
            msg = client.messages.create(
                model="claude-opus-4-5",
                max_tokens=600,
                system="""Write a 60-second YouTube news script in clear broadcast style.
Structure: Hook (10s) → Context (20s) → Key Facts (20s) → Closing (10s).
Include [IMAGE: description] markers where visuals should change.
Exactly 150-160 words. Return plain text only.""",
                messages=[{"role":"user","content":f'Write a 60-second YouTube news script for: "{topic}"'}]
            )
            return Response(json.dumps({"script": msg.content[0].text}), 200, headers)

        # ── IMAGE PACK ────────────────────────────────────────────────────────
        elif action == "pack":
            msg = client.messages.create(
                model="claude-opus-4-5",
                max_tokens=900,
                system="""You are a video producer. Generate 8 shot-by-shot copyright-free
image search queries for a YouTube news video. Return ONLY valid JSON:
{"shots":[{"timestamp":"0:00-0:10","purpose":"Opening hook",
"query":"specific search query","bestSource":"Wikimedia Commons","tip":"short tip"}]}
Exactly 8 shots. Best sources: DVIDS, NASA, Wikimedia Commons, PIB India, Unsplash, Pexels, VOA""",
                messages=[{"role":"user","content":f'News headline: "{topic}"'}]
            )
            return Response(clean_json(msg.content[0].text), 200, headers)

        else:
            return Response(json.dumps({"error": "Unknown action"}), 400, headers)

    except Exception as ex:
        import traceback
        print(traceback.format_exc())
        return Response(json.dumps({"error": str(ex)}), 500, headers)


def clean_json(text):
    """Extract JSON from AI response robustly."""
    import json, re
    text = re.sub(r"```json\s*", "", text)
    text = re.sub(r"```\s*", "", text).strip()
    start = len(text)
    for ch in ["{", "["]:
        idx = text.find(ch)
        if idx != -1:
            start = min(start, idx)
    end = max(text.rfind("}"), text.rfind("]"))
    if start == len(text) or end == -1:
        return text
    extracted = text[start:end+1]
    # Validate
    json.loads(extracted)
    return extracted


class Response:
    def __init__(self, body, status=200, headers=None):
        self.body = body
        self.status_code = status
        self.headers = headers or {}
